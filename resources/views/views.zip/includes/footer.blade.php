<footer class="page-footer blue">
  <div class="container">
  </div>
  <div class="footer-copyright">
    <div class="container">
      © 2016 Babycare
      <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
    </div>
  </div>
</footer>