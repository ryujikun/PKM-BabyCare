<?php $__env->startSection('page-title'); ?>
    Pertanyaan : BabyCare
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('nav-title'); ?>
    Pertanyaan
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

        <div class="container-fluid">
            <div class="col">
                <ul class="collection">

                    <?php foreach($items as $item): ?>


                    <li class="collection-item avatar">
                        <i class="material-icons circle <?php echo e($item->answer_id==null ? 'red' : 'green'); ?>">
                        </i>
                        <span class="title truncate">
                            <?php echo e($item->question); ?>

                        </span>
                            <span class="small">
                                <?php echo e($item->user->name); ?>

                            </span>
                        <?php if($item->answer!=null): ?> <span class="green-text">
                                Terjawab
                            </span>
                            <p class="truncate">
                                <?php echo e($item->answer->body); ?>

                            </p>
                        <?php else: ?>
                            <p class="red-text">
                                Belum dijawab
                            </p>
                            <a class="secondary-content btn btn-default right-align green" href="<?php echo e(url('answer/'.$item->id)); ?>">
                                Jawab
                            </a>
                            <?php endif; ?>

                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-foot'); ?>

    <script type="text/javascript">
        $(document).ready(function(){

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>