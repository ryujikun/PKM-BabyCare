<?php $__env->startSection('page-title'); ?>
    BabyCare : Dokter Peduli
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-title'); ?>
    Data Imunisasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="col">
            <ul class="collection">

                <?php if($filled): ?>
                    <ul class="collapsible" data-collapsible="accordion">
                    <?php foreach($items as $item): ?>
                        <li>
                            <div class="collapsible-header <?php echo e(isset($item->document_index) ? '' : 'red lighten-4'); ?>">

                                <div class="row valign-wrapper">
                                    <div class="col s8">
                                        <p class="flow-text"> <strong><?php echo e($item->name); ?></strong>
                                        dan Ibu <?php echo e(isset($item->mother->name) ? $item->mother->name : ''); ?>

                                        <br>
                                            <?php if(isset($item->document_index)): ?>
                                            <span class="small green-text">
                                                Data Imunisasi Tersedia.
                                            </span>
                                                <?php else: ?>

                                                <span class="small red-text">
                                                    Data Imunisasi tidak tersedia.
                                                </span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="col s2">
                                        <img src="<?php echo e(isset($item->path_picture) ?
                                                url('images/web/'.$item->path_picture)
                                                : url('images/web/babyDefaultPic.jpg')); ?>" alt="" class="circle responsive-img">
                                    </div>
                                    <div class="col s2">
                                        <img src="<?php echo e(isset($item->mother->path_picture) ?
                                                url('images/web/'.$item->mother->path_picture)
                                                : url('images/motherDefaultPic.png')); ?>" alt="" class="circle responsive-img">
                                    </div>
                                </div>

                            </div>
                            <div class="collapsible-body">

                                <?php if(isset($item->document_index)): ?>
                                    <p>
                                        <span class="flow-text">
                                            Silahkan unggah dengan klik tombol dibawah ini.
                                        </span>
                                        <br>
                                        <br>
                                        <a href="<?php echo e(url('detailImun/'.$item->id)); ?>" class="btn green lighten-1 white-text">
                                            Lihat Detail
                                        </a>
                                        <br>
                                        <br>
                                        <a href="<?php echo e(url('uploadImunisasi/'.$item->id)); ?>" class="btn green lighten-1 white-text">
                                            Perbarui Data
                                        </a>
                                    </p>
                                <?php else: ?>
                                    <p>
                                        <span class="flow-text">
                                            Silahkan unggah dengan klik tombol dibawah ini.
                                        </span>
                                        <br>
                                        <a href="<?php echo e(url('uploadImunisasi/'.$item->id)); ?>" class="btn green lighten-1 white-text">
                                            Ke Halaman Unggah Data
                                        </a>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>

                <?php else: ?>
                    <div class="container">

                        <div class="s12 grey lighten-4">
                            <blockquote>
                                <h5 class="red-text">
                                    <i class="material-icons">warning</i> Tidak ada data imunisasi tersedia!
                                </h5
                                <br>
                                <strong>Segera perbarui data.</strong>
                            </blockquote>
                        </div>
                    </div>
                <?php endif; ?>
            </ul>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-foot'); ?>

    <script type="text/javascript">
        $(document).ready(function(){

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>