<?php $__env->startSection('page-title'); ?>
    BabyCare : Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-title'); ?>
    Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.sheets_script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <div class="row">
            <form class="col s12" role="form" method="POST" action="" enctype="multipart/form-data">
                <h2 class="header"><?php echo e(isset($item->document_index)? 'Perbarui ' : 'Tambah '); ?> Data Imunisasi</h2>
                <?php echo e(csrf_field()); ?>


                <div class='row'>
                    <div class="input-field col s12">
                        <h4 class="flow-text">Data Imunisasi Sebelumnya</h4>
                        <div class="input-field">
                            <?php if(isset($item->document_index)): ?>
                                <div class="s12" id="jadwal">
                                </div>
                            <?php else: ?>
                                <div class="s12 grey lighten-4">
                                    <blockquote>
                                        <br>
                                        <h5 class="red-text">
                                            <i class="material-icons">warning</i> Data Imunisasi Bayi Anda tidak tersedia
                                        </h5
                                        <strong>Segera kunjungi posyandu dan minta kader posyandu mengunggah data bayi anda.<br></strong>
                                        <br>
                                    </blockquote>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class='row'>
                    <div class="input-field col s12">
                        <p class="flow-text">Data Imunisasi Baru</p>
                        <div class="file-field input-field">
                            <div class="btn">
                                <span>File</span>
                                <input name="xx" type="file">
                            </div>
                            <div class="file-path-wrapper">
                                <input class="file-path validate" type="text" >
                            </div>
                            <?php if($errors->has('xx')): ?>
                                <span class="red-text text-darken-1">
                                        <strong><?php echo e($errors->first('xx')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <span class="red-text text-darken-1">
                    <strong>Note:  </strong>Yang dapat diterima hanyalah format spreadsheet sepert Microsoft Excel, ODS, dll.
                    </span>
                <br>
                <br>

                <div class="row">

                    <button class="btn btn-large waves-effect waves-light right" type="submit" name="action">Perbarui
                        <i class="material-icons right">send</i>
                    </button>
                </div>
            </form>
        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_foot'); ?>

    <script type="text/javascript">
        //        var json;
        $(document).ready(function(){

            $.ajax({
                url : "<?php echo e(url('json/'.$item->id)); ?>",
                type : "GET",
                dataType : 'json',
                success : function(data) {
                    console.log(data);

                    var container = document.getElementById('jadwal');
                    var hot = new Handsontable(container, {
                        data: data,
                        dropdownMenu: true,
                        readOnly : true
                    });
                }
            });


        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>