<div class="navbar-fixed">
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" class="brand-logo" href="<?php echo e(url('/')); ?>">
            <?php /*<?php echo $__env->yieldContent('nav-title'); ?>*/ ?>
            BabyCare
      </a>
      <ul class="right hide-on-med-and-down">


        <?php if(!Auth::user()): ?>
          <li><a href="<?php echo e(url('/login')); ?>">Log In</a>
          <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="<?php echo e(url('/login')); ?>">Log In</a>
        <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
      </ul>
      <?php elseif(Auth::user()->isMommy()): ?>
        <li><a href="<?php echo e(url('dokterpeduli')); ?>">Dokter Peduli</a></li>
        <li><a href="<?php echo e(url('explore')); ?>">Zona Bayi</a></li>
        <li><a href="<?php echo e(url('motherzone')); ?>">Zona Ibu</a></li>
        <li><a href="<?php echo e(url('pertumbuhanku')); ?>">Pertumbuhanku</a></li>
        <li><a href="<?php echo e(url('/mother')); ?>">Profil</a></li>
        <?php /*<li><a href="<?php echo e(url('ibusiaga')); ?>">Ibu Siaga</a></li>*/ ?>
        <li><a href="<?php echo e(url('logout')); ?>">
            Logout</a></li>
        </ul>

        <ul id="nav-mobile" class="side-nav">
          <li><a href="<?php echo e(url('/mother')); ?>">Home</a></li>
          <li><a href="<?php echo e(url('dokterpeduli')); ?>">Dokter Peduli</a></li>
          <li><a href="<?php echo e(url('explore')); ?>">Zona Bayi</a></li>
          <li><a href="<?php echo e(url('motherzone')); ?>">Zona Ibu</a></li>
          <li><a href="<?php echo e(url('pertumbuhanku')); ?>">Pertumbuhanku</a></li>
          <li><a href="<?php echo e(url('/mother')); ?>">Profil</a></li>
          <?php /*<li><a href="<?php echo e(url('ibusiaga')); ?>">Ibu Siaga</a></li>*/ ?>
          <li><a href="<?php echo e(url('logout')); ?>">
              Logout</a></li>
        </ul>
      <?php elseif(Auth::user()->isDoctor()): ?>
        <li><a href="<?php echo e(url('doctor')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('answer')); ?>">Jawab Pertanyaan</a></li>
        <li><a href="<?php echo e(url('question')); ?>">Daftar Pertanyaan</a></li>
        <li><a href="<?php echo e(url('profil')); ?>">Profil</a></li>
        <li><a href="<?php echo e(url('logout')); ?>">
            Logout</a></li>
        </ul>

        <ul id="nav-mobile" class="side-nav">
          <li><a href="<?php echo e(url('doctor')); ?>">Home</a></li>
          <li><a href="<?php echo e(url('answer')); ?>">Jawab Pertanyaan</a></li>
          <li><a href="<?php echo e(url('question')); ?>">Daftar Pertanyaan</a></li>
          <li><a href="<?php echo e(url('profil')); ?>">Profil</a></li>
          <li><a href="<?php echo e(url('logout')); ?>">
              Logout</a></li>
        </ul>
      <?php elseif(Auth::user()->isKader()): ?>
        <li><a href="<?php echo e(url('/kader')); ?>">Data Imunisasi</a></li>
        <li><a href="<?php echo e(url('babydata')); ?>">Data Bayi</a></li>
        <li><a href="<?php echo e(url('profil')); ?>">Profil</a></li>
        <li><a href="<?php echo e(url('logout')); ?>">
            Logout</a></li>
        </ul>

        <ul id="nav-mobile" class="side-nav">
          <li><a href="<?php echo e(url('/kader')); ?>">Data Imunisasi</a></li>
          <li><a href="<?php echo e(url('babydata')); ?>">Data Bayi</a></li>
          <li><a href="<?php echo e(url('profil')); ?>">Profil</a></li>
          <li><a href="<?php echo e(url('logout')); ?>">
              Logout</a></li>
        </ul>
      <?php endif; ?>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>


  </nav>


</div>