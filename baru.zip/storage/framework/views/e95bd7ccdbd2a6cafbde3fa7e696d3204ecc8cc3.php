<?php $__env->startSection('page-title'); ?>
    Explore : Babycare
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-title'); ?>
    Explore
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    </div>


    <div class="container">
        <h2 class="header">Explore!</h2>
        <blockquote>
            <?php /*<?php echo e(dd($success)); ?>*/ ?>
            <?php if($errors->has()): ?>
                    <?php foreach($errors->all() as $error): ?>
                    <span class="red-text">
                        <?php echo e($error); ?>

                    </span> <br>
                    <?php endforeach; ?>
            <?php elseif(isset($success)): ?>
                <span class="green-text">
                    <?php echo e($success); ?>

                </span>
            <?php endif; ?>

        </blockquote>
    </div>
    <div class="fluid-container">
        <div class="row">
            <?php foreach($items as $item): ?>
            <div class="col s4  no-pad no-margin">
                <div class="card  no-pad no-margin">
                    <div class="card-image" style="position: relative;">
                       <form action="<?php echo e(URL::to('hapusfoto')); ?>" method="POST">
                           <input type="hidden" value="<?php echo e($item->id); ?>" name="idfoto">
                           <?php echo e(csrf_field()); ?>

                           <!-- <button type="submit">DELETE</button> -->
                           <input type="image" src="<?php echo e(URL::to('images/delete.png')); ?>" style="margin:10px;z-index:3;position: absolute;"></input>
                       </form>
                       <img class="materialboxed" src="<?php echo e(url('/images/web/'.$item->path_picture)); ?>" style="z-index: 2;">
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="fixed-action-btn" style="bottom: 45px; right: 24px;">
        <a class="btn-floating btn-large waves-effect waves-light red modal-trigger" href="#addPost">
            <i class="material-icons">add</i>
        </a>
    </div>
    <?php /*the modal form is here*/ ?>
    <div id="addPost" class="modal">
        <div class="modal-content">
            <h4>Tambahkan Post</h4>
            <hr>
            <p class="red-text">Ukuran file maksimal 1 MB</p>

            <form class="col s12" method="post" enctype="multipart/form-data" action="">
                <?php echo e(csrf_field()); ?>

                <div class="file-field input-field">
                    <div class="btn">
                        <span>Foto Bayi</span>
                        <input type="file" accept="image/*" name="image" onchange="loadFile(event)">
                    </div>
                    <div class="file-path-wrapper">
                        <input class="file-path validate" type="text">
                    </div>
                </div>
                <div class="row">
                    <img id="output" style="max-width: 100%"/>
                </div>
                <script>
                    var loadFile = function(event) {
                        var output = document.getElementById('output');
                        output.src = URL.createObjectURL(event.target.files[0]);
                    };
                </script>
        </div>
        <div class="modal-footer">
            <a class="modal-action modal-close waves-effect waves-green btn-flat ">Batal</a>
            <button type="submit" class="modal-action waves-effect waves-green btn ">Post</button>
        </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-foot'); ?>

    <script type="text/javascript">
        $(document).ready(function(){

            // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
            $('.modal-trigger').leanModal({

                dismissible: true, // Modal can be dismissed by clicking outside of the modal
                opacity: .5, // Opacity of modal background
                in_duration: 300, // Transition in duration
                out_duration: 200, // Transition out duration
                starting_top: '4%', // Starting top style attribute
                ending_top: '10%',
                height:'50%'// Ending top style attribute
            });


        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>