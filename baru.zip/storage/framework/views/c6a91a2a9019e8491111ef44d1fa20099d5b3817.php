<?php $__env->startSection('page-title'); ?>
    Register Babycare
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    </div>

    <div class="section no-pad-bot" id="index-banner">
        <div class="container">
            <div class="row">
                <form class="col s12" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <h2 class="header">Log In Babycare</h2>
                    <br>
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="input-field col s12">
                            <input id="email" type="email" name='email' class="validate">
                            <label for="email">Email</label>
                            <?php if($errors->has('email')): ?>
                                <span class="red-text text-darken-1">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input id="password" name='password' type="password" class="validate">
                            <label for="password">Password</label>
                            <?php if($errors->has('password')): ?>
                                <span class="red-text text-darken-1">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <button class="btn btn-large waves-effect waves-light right" type="submit" name="action">
                        log In
                        <i class="material-icons right">send</i>
                    </button>
                </form>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-foot'); ?>

    <script type="text/javascript">
        $('#address').val('New Text');
        $('#address').trigger('autoresize');

        $('.datepicker').pickadate({
            selectYears:true,
            selectYears: 60
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>