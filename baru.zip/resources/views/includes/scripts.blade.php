

    <!--  Scripts-->
    <script type="text/javascript" src="{{ url('assets/js/jquery-2.1.1.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/materialize.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/date_picker/picker.date.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/jquery.timeago.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/date_picker/picker.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/jquery.easing.1.3.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/init.js') }}"></script>
