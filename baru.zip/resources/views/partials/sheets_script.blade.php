<!--
 Loading Handsontable (full distribution that includes all dependencies)
 -->
<link data-jsfiddle="common" rel="stylesheet" media="screen" href="{{ url('dist/handsontable.css') }}">
<link data-jsfiddle="common" rel="stylesheet" media="screen" href="{{ url('dist/pikaday/pikaday.css') }}">
<script data-jsfiddle="common" src="{{ url('dist/pikaday/pikaday.js') }}"></script>
<script data-jsfiddle="common" src="{{ url('dist/moment/moment.js') }}"></script>
<script data-jsfiddle="common" src="{{ url('dist/zeroclipboard/ZeroClipboard.js') }}"></script>
<script data-jsfiddle="common" src="{{ url('dist/handsontable.js') }}"></script>