<div class="navbar-fixed">
    <nav class="light-blue lighten-1" role="navigation">
        <div class="nav-wrapper container">
            <a id="logo-container" class="brand-logo" href="{{ url('/') }}">
                BabyCare
            </a>
            <ul class="right hide-on-med-and-down">
                    <li><a href="{{ url('/login') }}">Log In</a>
                    <li><a href="{{ url('/register') }}">Register</a></li>
            </ul>
        </div>


    </nav>


</div>